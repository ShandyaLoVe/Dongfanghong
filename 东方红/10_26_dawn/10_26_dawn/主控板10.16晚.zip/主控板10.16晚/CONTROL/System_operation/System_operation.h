#ifndef __SYSTEM_OPERATION_H
#define __SYSTEM_OPERATION_H

void System_TIM7_Init(void);
extern void VOFA_send(char *send,float data1,float data2);


#endif
