#ifndef __USART_MY_H
#define __USART_MY_H


//void USART1_Init(void);
//void USART2_Init(void);



#endif
