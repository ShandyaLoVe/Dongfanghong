#ifndef __TEST_H
#define __TEST_H


extern u8 time_5ms;
extern u8 time_7ms;
extern u8 time_10ms;
extern u8 time_20ms;
extern u8 time_50ms;
extern u8 time_100ms;
#endif
