#ifndef __COMMAND_H
#define __COMMAND_H

#include "sys.h"
float calculate_angle(void);
#define k 180/3.142


#endif

 
