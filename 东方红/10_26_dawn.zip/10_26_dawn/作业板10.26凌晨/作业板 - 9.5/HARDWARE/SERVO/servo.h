#ifndef __SERVO_H
#define __SERVO_H

#include "sys.h"



void servo_init(void);
void sevo1_angle(float x);


#endif
