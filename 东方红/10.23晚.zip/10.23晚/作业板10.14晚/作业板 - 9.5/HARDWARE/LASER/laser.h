#ifndef __LASER_H
#define __LASER_H

#include "sys.h"
void laser_init(void);
void laser_open(void);
void laser_close(void);

#endif
