#ifndef __BEEP_H
#define __BEEP_H

#include "sys.h"
void beep_init(void);

#endif
