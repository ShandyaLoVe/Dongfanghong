#ifndef __MIKE_H
#define __MIKE_H

#include "motor.h"
#define wheel_R 1
#define wheel_L1 6.7
#define wheel_L2 11.4

void mike_wheel(int vx,int vy,float yaw);

#endif

