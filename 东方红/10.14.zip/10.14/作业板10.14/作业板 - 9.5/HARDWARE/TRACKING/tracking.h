#ifndef __TRACKING_H
#define __TRACKING_H

#include "sys.h"
void tracking_init(void);
uint8_t tracking_read(void);
int Get_err(int Va);
#endif
