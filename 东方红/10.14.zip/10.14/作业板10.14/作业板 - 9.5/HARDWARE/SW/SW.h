#ifndef __SW_H
#define	__SW_H

#include "stm32f4xx.h"
#include "delay.h"
#include "sys.h"


#define KEY1 		PCin(10)   	                                                                             	//PB13
#define KEY2 		PCin(11)		                                                                         		//PG2
#define KEY3  	PEin(2)		                                                                         	//PA12
#define KEY4		PEin(3)

#define KEY1_PRES                 1
#define KEY2_PRES                 2
#define KEY3_PRES                 3
#define KEY4_PRES                 4

extern int key;

void Key_Init(void);
u8   Key_Scan(void);



#endif /* __KEY_H */

