#include "timer.h"                  // Device header
extern uint16_t Num;
void Timer_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM10, ENABLE);
	
	TIM_InternalClockConfig(TIM10);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 100000  - 1;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 16800 - 1;
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM10, &TIM_TimeBaseInitStructure);

//	TIM_ITConfig(TIM10, TIM_IT_Update, ENABLE);
//	
//	NVIC_InitTypeDef NVIC_InitStructure;
//	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_TIM10_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//	NVIC_Init(&NVIC_InitStructure);
//	
	TIM_Cmd(TIM10, ENABLE);
}

unsigned int n;
//unsigned int Timer10ms;
//void TIM10_IRQHandler(void)
//{
//	if (TIM_GetITStatus(TIM10, TIM_IT_Update) == SET)
//	{ 
//		n++;
//        Timer10ms++;
//		TIM_ClearITPendingBit(TIM10, TIM_IT_Update);
//	}
//}

