#ifndef __TIMER_H
#define __TIMER_H

#include "sys.h"
void Timer_Init(void);
extern unsigned int n;

#endif
